* Configure .env
* Execute with "cmd"
	